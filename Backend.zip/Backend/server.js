var express = require('express');

 
var Routes= require('./router/UserRoutes');
const route = require('./router/UserRoutes');

//testing model 



//create object
var app = express(); 

const port=4000;

//configuration code for accepting json data / form data from ui
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//register the router

// app.use('/test',testrouter);
app.use('/usr',Routes);

//listen the server on the port 

app.listen(port,()=>{
    console.log(`the server is running in the port ${port}....!`);
})
