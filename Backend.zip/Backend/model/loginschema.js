const mongoose=require('../database/connect');

const loginSchema= mongoose.Schema(
    {
        // _id:{
        //     type: String,
        //     required: true,
        // },
        name:{
            type: String,
            required: true,
            
        },
        email:{
            type: String,
            required: true,
        },
        pwd:{
            type: String,
            required: true,
        
        },}
);
const logSchema= mongoose.model('login',loginSchema);

module.exports=logSchema;