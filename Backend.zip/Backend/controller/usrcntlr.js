const User = require('../model/usrschema');
const multer = require('multer');

// Set up multer for handling file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

class usrController {
    static async showall(req, res) {
        try {
            const info = await User.find();
            res.status(200).json({ data: info });
        } catch (err) {
            console.log(err);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    static async finduser(req, res) {
        try {
            let rid = req.params.id;
            const data = await User.findById(rid);
            res.status(200).json({ info: data });
        } catch (err) {
            console.log(err);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    static async adduser(req, res) {
        try {
            
            let uid = req.body;
    
            
            const ulp = new User();
    
            
            ulp.title = uid.title;
            ulp.description = uid.description;
            ulp.price = uid.price;
            ulp.rating = uid.rating;
            ulp.stock = uid.stock;
            ulp.brand = uid.brand;
            ulp.category = uid.category;
    
            // Check if req.files is an array and not empty
            if (!Array.isArray(req.files) || req.files.length === 0) {
                return res.status(400).json({ error: 'No files were uploaded.' });
            }
    
            // Extract file buffers from the request
            const thumbnail = req.files[0].buffer.toString('base64');
            const images = req.files.slice(1).map(file => file.buffer.toString('base64'));
    
            // Set properties for file uploads
            ulp.thumbnail =thumbnail;
            ulp.images = images;
    
            // Save the user data to the database
            const result = await ulp.save();
    
            // Send a response to the client
            res.status(200).json({ msg: 'Insertion is done', info: result });
        } catch (err) {
            console.error(err);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    
    

    static async upduser(req, res) {
        try {
            let uid = req.params.id;
            let ulp = req.body;
            const uupd = await User.findByIdAndUpdate(uid, ulp, { new: true });
            res.status(200).json({ msg: 'update is success', data: uupd });
        } catch (err) {
            console.log(err);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    static async deluser(req, res) {
        try {
            let uid = req.params.id;
            const result = await User.deleteOne({ _id: uid });
            res.status(200).json({ msg: 'delete success', info: result });
        } catch (err) {
            console.log(err);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}

module.exports = usrController;
