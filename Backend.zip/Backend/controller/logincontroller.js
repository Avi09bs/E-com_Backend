const log= require('../model/loginschema');
const jwt= require('jsonwebtoken');

class logController{
    static async register(req, res) {
        try {
            const userData = req.body;

            // Validate user input (e.g., check for required fields)
            // You may also want to perform additional validation and sanitation

            const newUser = new log(userData);
            const result = await newUser.save();

            res.status(201).json({ msg: 'Registration successful', data: result });
        } catch (err) {
            console.error(err);
            res.status(500).json({ msg: 'Internal Server Error' });
        }
    }

    static async login(req, res) {
        try {
            const { email, pwd } = req.body;

            // Find user by email
            const existingUser = await log.findOne({ email });

            if (!existingUser) {
                return res.status(401).json({ msg: 'Invalid credentials' });
            }

            // Check if the password is correct (you may need to hash and compare)
            if (existingUser.pwd !== pwd) {
                return res.status(401).json({ msg: 'Invalid credentials' });
            }

            // Generate and send a token for authentication
            const token = jwt.sign({ userId: existingUser._id }, 'your-secret-key');
            res.status(200).json({ msg: 'Login successful', token });
        } catch (err) {
            console.error(err);
            res.status(500).json({ msg: 'Internal Server Error' });
        }
    }

}
module.exports= logController;