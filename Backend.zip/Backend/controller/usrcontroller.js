// const user = require('../model/usrschema.js');
// // const jwt = require('jsonwebtoken');
// // const multer = require('multer');

// // const storage = multer.diskStorage({
// //     destination: function (req, file, cb) {
// //         cb(null, 'uploads/'); // Specify the directory where you want to store the uploaded files
// //     },
// //     filename: function (req, file, cb) {
// //         cb(null, Date.now() + '-' + file.originalname);
// //     }
// // });

// // const upload = multer({ storage: storage });

// class usrController {
//     static async showall(req, res) {
//         try {
//             const info = await user.find();
//             res.status(200).json({ data: info });
//         } catch (err) {
//             console.log(err);
//         }
//     }

//     static async finduser(req, res) {
//         try {
//             let rid = req.params.id;
//             const data = await user.findById(rid);
//             res.status(200).json({ info: data });
//         } catch (err) {
//             console.log(err);
//         }
//     }

    // static async adduser(req, res) {
    //     try {
    //         let uid = req.body;
    //         console.log(uid);
    //         const ulp = new user();
            
    //         ulp.title = uid.title;
    //         ulp.description = uid.description;
    //         ulp.price = uid.price;
    //         ulp.rating = uid.rating;
    //         ulp.stock = uid.stock;
    //         ulp.brand = uid.brand;
    //         ulp.category = uid.category;
    //         const result = await ulp.save();
    //         res.status(200).json({ msg: 'insert is done', info: result });
    //     } catch (err) {
    //         console.log(err);
    //     }
    // }

//     static async upduser(req, res) {
//         try {
//             let uid = req.params.id;
//             let ulp = req.body;
//             const uupd = await user.findById(uid);
            
//             uupd.title = ulp.title;
//             uupd.description = ulp.description;
//             uupd.price = ulp.price;
//             uupd.rating = ulp.rating;
//             uupd.stock = ulp.stock;
//             uupd.brand = ulp.brand;
//             uupd.category = ulp.category;
//             const result = await uupd.save();
//             res.status(200).json({ msg: 'update is success', data: result });
//         } catch (err) {
//             console.log(err);
//         }
//     }

//     static async deluser(req, res) {
//         try {
//             let uid = req.params.id;
//             const result = await user.deleteOne({ _id: uid });
//             res.status(200).json({ msg: 'delete success', info: result });
//         } catch (err) {
//             console.log(err);
//         }
//     }

   

//     // static async multiFileUpload(req, res) {
//     //     try {
//     //         // Use the 'upload' middleware to handle multiple file uploads
//     //         upload.array('files', 5)(req, res, async function (err) {
//     //             if (err instanceof multer.MulterError) {
//     //                 return res.status(400).json({ msg: 'File upload error' });
//     //             } else if (err) {
//     //                 return res.status(500).json({ msg: 'Internal Server Error' });
//     //             }

//     //             // Access the uploaded files in req.files
//     //             const files = req.files;

//     //             // Process the files or store their information in the database
//     //             // ...

//     //             res.status(200).json({ msg: 'Files uploaded successfully', files });
//     //         });
//     //     } catch (err) {
//     //         console.error(err);
//     //         res.status(500).json({ msg: 'Internal Server Error' });
//     //     }
//     // }
// }

// module.exports = usrController;
